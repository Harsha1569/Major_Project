%clc;
close all;
clear;

% Fs = 8000;                  
% dt = 1/Fs;                  
% StopTime = 0.25;             
% t = (0:dt:StopTime-dt)';    
% Fc = 60;                   
% X = cos(2*pi*Fc*t);
% [signal,Fs] = audioread('Audio.wav');
% X =signal(100000:105000,1);
% figure;
% plot(abs(fft(X)))
SNR = 15;
X=dlmread("f_case3_fps_30_180s.dat");
avg = mean(X);
fitted_signal = X - avg;

XN = awgn(fitted_signal,SNR,'measured',15);
input_snr = evaluate_denoising_metrics(fitted_signal, XN);
%avg = mean(X);
%fitted_signal = X - avg;

%audiowrite('noisy.wav',XN,Fs)

figure;
subplot(3,1,1);
plot(fitted_signal)
title('Original Signal','FontSize',16);
xlabel('Sample number(n)','FontSize',12); ylabel ('Amplitude','FontSize',12);
% xlabel('Time (s)','FontSize',12); ylabel ('Amplitude','FontSize',12);
legend('Original Signal','FontSize',12)
grid on

subplot(3,1,2); 
plot(XN)
title('Signal after adding Gaussian White Noise','FontSize',16);
xlabel('Sample number (n)','FontSize',12); ylabel ('Amplitude','FontSize',12);
% xlabel('Time (s)','FontSize',12); ylabel ('Amplitude','FontSize',12);
legend('Signal with Noise','FontSize',12)
grid on

best_snr = -99999;
for i = 1:10
    [C,L] = wavedec(XN,i,'db4');
    temp_xd = wrcoef('a',C,L,'db4',i);
    temp_snr = evaluate_denoising_metrics(fitted_signal,temp_xd) ;
    if(temp_snr > best_snr)
        mode = i;
        best_snr = temp_snr;
        xd = temp_xd;
    end
end
%audiowrite('Filtered.wav',xd,Fs)

%audiowrite('Filtered.wav',xd,Fs)

subplot(3,1,3); 
plot(xd)
title('Denoised Signal','FontSize',16);
xlabel('Sample number(n)','FontSize',12); ylabel ('Amplitude','FontSize',12);
% xlabel('Time (s)','FontSize',12); ylabel ('Amplitude','FontSize',12);
legend('Filtered signal','FontSize',12)
% ylim([-0.03 0.02])
grid on


figure;
plot(fitted_signal,'b')
grid on
hold on;
plot(xd)
legend('Original Signal','Denoised Signal','Location','NorthEast','FontSize',10)
xlabel('Sample number(n)','FontSize',12); ylabel ('Amplitude','FontSize',12);
axis tight;
hold off;
output_snr = evaluate_denoising_metrics(fitted_signal,xd) 
