clc;
close all;
clear;

Fs = 8000;                  
dt = 1/Fs;                  
StopTime = 0.25;             
t = (0:dt:StopTime-dt)';    
Fc = 60;                   
% X = cos(2*pi*Fc*t);

[signal,Fs] = audioread('Audio.wav');
X =signal(100000:105000,1);

%X=dlmread("f_case3_fps_30_180s.dat");

SNR_array = [5,10,15,25,35,45];
arr_size = 6;
OUTPUT_SNR_array = ones(arr_size, 10);


seed = 15;

for k = 1:arr_size

    avg = mean(X);
    fitted_signal = X - avg;
    
    XN = awgn(fitted_signal,SNR_array(k),'measured',15);
    input_snr = evaluate_denoising_metrics(fitted_signal, XN);
    
    best_snr = -99999;
    for i = 1:10
        [C,L] = wavedec(XN,i,'db4');
        temp_xd = wrcoef('a',C,L,'db4',i);
        OUTPUT_SNR_array(k,i) = evaluate_denoising_metrics(fitted_signal,temp_xd) ;
    end

end

OUTPUT_SNR_array

figure;
plot(OUTPUT_SNR_array(1,1:8),'b*-')
grid on
hold on;
plot(OUTPUT_SNR_array(3,1:8),'r*-')
plot(OUTPUT_SNR_array(5,1:8),'g*-')
legend('Input SNR = 5dB','Input SNR = 15dB','Input SNR = 35dB','Location','NorthEast')
title('Signal to Noise Ratio VS Level of decomposition','FontSize',16);
xlabel('Level of Decomposition','FontSize',12); ylabel ('Output SNR (dB)','FontSize',12);
axis tight;
hold off;