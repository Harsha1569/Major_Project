function [flatness] = spectral_flatness(signal)
L = length(signal);
original_signal =signal(1:L);
f_spectrum = fft(original_signal);
amp = abs(f_spectrum/L);
power_spectrum = amp(1 : L/2 + 1);
power_spectrum(2 : L/2 + 1) = 2 * power_spectrum(2 : L/2 + 1) .* power_spectrum(2 : L/2 + 1);
num = 0;
den = 0;
N = L / 2 + 1;
for i = 1 : N
    num = num + log(power_spectrum(i));
    den = den + power_spectrum(i);
end
num = exp(num / N);
den = den / N;
flatness = num / den;
end