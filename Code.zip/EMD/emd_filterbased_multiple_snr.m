clc;
close all;
clear;

% Fs = 8000;                  
% dt = 1/Fs;                  
% StopTime = 0.25;             
% t = (0:dt:StopTime-dt)';    
% Fc = 60;                   
% original_signal = cos(2*pi*Fc*t);

% [signal,Fs] = audioread('Audio.wav');
% original_signal =signal(100000:105000,1);

original_signal = dlmread("f_case3_fps_30_180s.dat");

SNR_array = [5,10,15,25,35,45];
OUTPUT_SNR_array = [5,10,15,25,35,45];
arr_size = 6;

seed = 15;

for k = 1:arr_size
    avg = mean(original_signal);
    fitted_signal = original_signal - avg;
    
    a = awgn(fitted_signal,SNR_array(k),'measured',seed);
    input_snr = evaluate_denoising_metrics(original_signal - avg, a);
    
    best_threshold = emd_spectralflatness_filter_threshold(original_signal - avg, a);
    
    Fs = 22000;
    F = 10;
    [y, x] = butter(5, F/(Fs/2), 'low');
    
    imf= emd(a); %Computes the EMD
    imf=imf' ;	  %Store the IMFs as column vectors 
    s=size(imf);
    h=zeros(1,s(2));
    b=a';
    for i=1:s(2)
    flatness = spectral_flatness(imf(:,i)');
    if (flatness > best_threshold)
        b = b - imf(:,i)';
        b = b + filter(y, x, imf(:,i)');
    end
    end

    OUTPUT_SNR_array(k) = evaluate_denoising_metrics(original_signal - avg,b); 	%evaluates denoising metrics

end

OUTPUT_SNR_array