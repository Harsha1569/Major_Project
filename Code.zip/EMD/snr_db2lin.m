function [snr_lin] = snr_db2lin(snr_db)
    snr_lin = 10 ^ (snr_db / 10);
end