clc;
close all;
clear;

Fs = 8000;                  
dt = 1/Fs;                  
StopTime = 0.25;             
t = (0:dt:StopTime-dt)';    
Fc = 60;                   
original_signal = cos(2*pi*Fc*t);
% [signal,Fs] = audioread('Audio.wav');
% original_signal =signal(100000:105000,1);

%original_signal = dlmread("f_case3_fps_30_180s.dat");

SNR = 15;
seed = 15;

avg = mean(original_signal);
fitted_signal = original_signal - avg;

a = awgn(fitted_signal,SNR,'measured',seed);
input_snr = evaluate_denoising_metrics(original_signal - avg, a);

best_threshold = emd_spectralflatness_subtraction_threshold(original_signal - avg, a);

figure;
subplot(3,1,1);
plot(fitted_signal)
title('Original Signal','FontSize',16);
xlabel('Time (s)','FontSize',12); ylabel ('Amplitude','FontSize',12);
legend('Original Signal','FontSize',12)
axis tight;
grid on

subplot(3,1,2); 
plot(a)
title('Signal after adding Gaussian White Noise','FontSize',16);
xlabel('Time (s)','FontSize',12); ylabel ('Amplitude','FontSize',12);
legend('Signal with Noise','FontSize',12)
axis tight;
grid on

imf= emd(a); %Computes the EMD
imf=imf' ;	  %Store the IMFs as column vectors 
s=size(imf);
h=zeros(1,s(2));
b=a';
for i=1:s(2)
flatness = spectral_flatness(imf(:,i)');
if (flatness > best_threshold)
    i
    b=b-imf(:,i)';
end
end

subplot(3,1,3); 
plot(b)
title('Denoised Signal','FontSize',16);
xlabel('Time (s)','FontSize',12); ylabel ('Amplitude','FontSize',12);
legend('Filtered signal','FontSize',12)
grid on
axis tight;

output_snr = evaluate_denoising_metrics(original_signal - avg,b) 	%evaluates denoising metrics

figure;
plot(fitted_signal,'b')
grid on
hold on;
plot(b)
legend('Original Signal','Denoised Signal','Location','NorthEast','FontSize',10)
xlabel('Sample number(n)','FontSize',12); ylabel ('Amplitude','FontSize',12);
axis tight;
hold off;

figure;
imf_size = size(imf);
imf_num = imf_size(2);
for z=1:imf_num
subplot(imf_num,1,z); 
plot(imf(:,z))
if(z==1)
    title('IMFs of the Nosiy Signal');
end
xlabel('Time (s)'); ylabel ('Amplitude');
legend('Filtered Signal')
grid on
end
xlabel('Sample number(n)','FontSize',12); ylabel ('Amplitude','FontSize',12);
