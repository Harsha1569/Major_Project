function [best_threshold] = emd_spectralflatness_subtraction_threshold(fitted_signal, a)


imf= emd(a); %Computes the EMD
imf=imf' ;	  %Store the IMFs as column vectors 
s=size(imf);
h=zeros(1,s(2));
b=a';

best_snr = -99999;
best_threshold = 0.0001;
for temp_threshold = 0.0001 : 0.0001 : 0.1
    b=a';
    for i=1:s(2)
        flatness = spectral_flatness(imf(:,i)');
        if (flatness > temp_threshold)
            b=b-imf(:,i)';
        end
    end
    
    temp_snr = evaluate_denoising_metrics(fitted_signal, b );
    if temp_snr > best_snr
        best_threshold = temp_threshold;
        best_snr = temp_snr;
    end

end

end
