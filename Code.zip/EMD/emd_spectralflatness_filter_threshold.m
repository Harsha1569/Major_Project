function [best_threshold] = emd_spectralflatness_filter_threshold(fitted_signal, a)


imf= emd(a); %Computes the EMD
imf=imf' ;	  %Store the IMFs as column vectors 
s=size(imf);

Fs = 22000;
F = 10;
[y, x] = butter(4, F/(Fs/2), 'low');

best_snr = -99999;
best_threshold = 0.0001;
for temp_threshold = 0.0001 : 0.0001 : 0.1
    b=a';
    for i=1:s(2)
        flatness = spectral_flatness(imf(:,i)');
        if (flatness > temp_threshold)
            b = b - imf(:,i)';
            b = b + filter(y, x, imf(:,i)');
        end
    end
    
    temp_snr = evaluate_denoising_metrics(fitted_signal, b );
    if temp_snr > best_snr
        best_threshold = temp_threshold;
        best_snr = temp_snr;
    end

end

end