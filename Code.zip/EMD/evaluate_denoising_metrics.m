function [SNR] = evaluate_denoising_metrics(noisy,denoised)

temp=noisy;
y=denoised;

%SNR and PSNR %signal to noise ratio %peak signal to noise ratio
num=0;
den=0;
for i=1:length(temp)
den=den+(y(i)-temp(i))^2;
end
for i=1:length (temp)
num=num+temp(i)^2;
end
SNR = 20*log10(sqrt(num)/sqrt(den));

%fprintf('signal to noise ratio %f db\n',SNR);

end
