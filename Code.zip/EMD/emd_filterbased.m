clc;
close all;
clear;

% [signal,Fs] = audioread('Audio.wav');
% original_signal =signal(100000:105000,1);
% original_signal = dlmread("f_case3_fps_30_180s.dat");
% plot(abs(fft(original_signal)))
Fs = 8000;                  
dt = 1/Fs;                  
StopTime = 0.25;             
t = (0:dt:StopTime-dt)';    
Fc = 60;                   
original_signal = cos(2*pi*Fc*t);

SNR = 15;
seed = 15;

avg = mean(original_signal);
fitted_signal = original_signal - avg;

a = awgn(fitted_signal,SNR,'measured',seed);
input_snr = evaluate_denoising_metrics(original_signal - avg, a);

best_threshold = emd_spectralflatness_filter_threshold(original_signal - avg, a);

figure;
subplot(3,1,1);
plot(fitted_signal)
title('Original Signal','FontSize',16);
xlabel('Time (s)','FontSize',12); ylabel ('Amplitude','FontSize',12);
legend('Original Signal','FontSize',12)
axis tight;
grid on

subplot(3,1,2); 
plot(a)
title('Signal after adding Gaussian White Noise','FontSize',16);
xlabel('Time (s)','FontSize',12); ylabel ('Amplitude','FontSize',12);
legend('Signal with Noise','FontSize',12)
axis tight;
grid on
Fs = 22000;
F = 10;
[y, x] = butter(5, F/(Fs/2), 'low');

imf= emd(a); %Computes the EMD
imf=imf' ;	  %Store the IMFs as column vectors 
new_imf = imf;
s=size(imf);
h=zeros(1,s(2));
b=a';
k = 1;
for i=1:s(2)
flatness = spectral_flatness(imf(:,i)');
if (flatness > best_threshold)
    arr(k) = i;
    k = k + 1;
    b = b - imf(:,i)';
    new_imf(:,i) = filter(y, x, imf(:,i)')';
    b = b + filter(y, x, imf(:,i)');
end
end

arr

subplot(3,1,3); 
plot(b)
title('Denoised Signal','FontSize',16);
xlabel('Time (s)','FontSize',12); ylabel ('Amplitude','FontSize',12);
legend('Filtered signal','FontSize',12)
grid on
axis tight;

output_snr = evaluate_denoising_metrics(original_signal - avg,b) 	%evaluates denoising metrics

figure;
plot(fitted_signal,'b')
grid on
hold on;
plot(b)
legend('Original Signal','Denoised Signal','Location','NorthEastOutside')
axis tight;
hold off;

fig1 = figure;
imf_size = size(imf);
imf_num = imf_size(2);
for z=1:imf_num
subplot(imf_num,1,z); 
plot(imf(:,z))
end

han=axes(fig1,'visible','off'); 
han.Title.Visible='on';
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'Amplitude','FontSize',14);
xlabel(han,'Time (s)','FontSize',14);
title(han,'IMFs of the Nosiy Signal before Filtering','FontSize',16);
grid on

fig2 = figure;
for z=1:imf_num
subplot(imf_num,1,z); 
plot(new_imf(:,z))
end

han=axes(fig2,'visible','off'); 
han.Title.Visible='on';
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'Amplitude','FontSize',14);
xlabel(han,'Time (s)','FontSize',14);
title(han,'IMFs of the Signal after Filtering','FontSize',16);
grid on
%end